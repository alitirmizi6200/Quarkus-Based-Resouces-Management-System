package com.example.resourceManagementSystem.travelAgent.flight;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import javax.validation.Validator;
import java.util.HashSet;
import java.util.Set;

@ApplicationScoped
public class FlightValidator {

    @Inject
    Validator validator;

    @Inject
    FlightRepository flightRepository;

    void validateFlight(Flight flight) throws ConstraintViolationException, ValidationException {
        // Create a bean validator and check for issues.
        Set<ConstraintViolation<Flight>> violations = validator.validate(flight);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(new HashSet<>(violations));
        }

        // Check additional constraints for Flight entity
        validatePointOfDeparture(flight.getPointOfDeparture());
        validateDestination(flight.getDestination(), flight.getPointOfDeparture());
    }

    private void validatePointOfDeparture(String pointOfDeparture) throws ValidationException {
        if (pointOfDeparture == null || !pointOfDeparture.matches("^[A-Z]{3}$")) {
            throw new ValidationException("Point of departure should be a non-empty alphabetical string, which is upper case and 3 characters in length.");
        }
    }

    private void validateDestination(String destination, String pointOfDeparture) throws ValidationException {
        if (destination == null || !destination.matches("^[A-Z]{3}$") || destination.equals(pointOfDeparture)) {
            throw new ValidationException("Destination should be a non-empty alphabetical string, which is upper case, 3 characters in length, and different from the point of departure.");
        }
    }
}
