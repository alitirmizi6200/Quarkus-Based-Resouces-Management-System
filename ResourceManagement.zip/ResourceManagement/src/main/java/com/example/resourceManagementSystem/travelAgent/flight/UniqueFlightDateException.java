package com.example.resourceManagementSystem.travelAgent.flight;

public class UniqueFlightDateException  extends RuntimeException{
    public UniqueFlightDateException(String message) {
        super(message);
    }

    public UniqueFlightDateException(String message, Throwable cause) {
        super(message, cause);
    }

    public UniqueFlightDateException(Throwable cause) {
        super(cause);
    }
}
