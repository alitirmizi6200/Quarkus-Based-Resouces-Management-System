package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.validation.ConstraintViolationException;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

@RequestScoped
public class HotelBookingRepository {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    EntityManager em;

    /**
     * <p>Returns a single HotelBooking object, specified by a HotelBooking ID.<p/>
     *
     * @param bookingID The ID of the booking
     * @return The booking with the specified ID
     */
    public HotelBooking findById(Long bookingID) {
        return em.find(HotelBooking.class, bookingID);
    }

    /**
     * <p>Returns a List of all persisted booking object ordered by Date.</p>
     *
     * @return List of Hotel objects
     */
    List<HotelBooking> findAllOrderedByID() {
        TypedQuery<HotelBooking> query = em.createNamedQuery(HotelBooking.FIND_BY_ID, HotelBooking.class);
        return query.getResultList();
    }

    /**
     * <p>Returns a list of Bookings objects, specified by a hotel ID.<p/>
     *
     * @param hotelId The ID of the hotel
     * @return The list of bookings in the specified hotel
     */
    public List<HotelBooking> findAllByHotelId(Long hotelId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<HotelBooking> criteria = cb.createQuery(HotelBooking.class);
        Root<HotelBooking> bookingRoot = criteria.from(HotelBooking.class);
        criteria.select(bookingRoot).where(cb.equal(bookingRoot.get("hotel").get("id"), hotelId));
        return em.createQuery(criteria).getResultList();
    }

    /**
     * <p>Returns a list of Bookings objects, specified by a customer ID.<p/>
     *
     * @param customerID The ID of the customer
     * @return The list of bookings in the specified customer
     */
    public List<HotelBooking> findAllByCustomerId(Long customerID) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<HotelBooking> criteria = cb.createQuery(HotelBooking.class);
        Root<HotelBooking> bookingRoot = criteria.from(HotelBooking.class);
        criteria.select(bookingRoot).where(cb.equal(bookingRoot.get("customer").get("id"), customerID));
        return em.createQuery(criteria).getResultList();
    }


    /**
     * Returns a single HotelBooking object for a specific hotel and date.
     *
     * @param hotelId     The ID of the hotel
     * @param bookingDate The date of the booking
     * @return The booking for the specified hotel and date, or null if not found
     */
    public HotelBooking findByHotelAndDate(Long hotelId, Date bookingDate) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<HotelBooking> criteria = cb.createQuery(HotelBooking.class);
        Root<HotelBooking> bookingRoot = criteria.from(HotelBooking.class);

        Join<HotelBooking, Hotel> hotelJoin = bookingRoot.join("hotel");

        Predicate hotelPredicate = cb.equal(hotelJoin.get("id"), hotelId);
        Predicate datePredicate = cb.equal(bookingRoot.get("bookingDate"), bookingDate);

        criteria.select(bookingRoot).where(cb.and(hotelPredicate, datePredicate));

        List<HotelBooking> resultList = em.createQuery(criteria).setMaxResults(1).getResultList();

        return resultList.isEmpty() ? null : resultList.get(0);
    }

    /**
     * <p>Persists the provided booking object to the application database using the EntityManager.</p>
     *
     * <p>{@link EntityManager#persist(Object) persist(Object)} takes an entity instance, adds it to the
     * context and makes that instance managed (i.e., future updates to the entity will be tracked)</p>
     *
     * <p>persist(Object) will set the @GeneratedValue @Id for an object.</p>
     *
     * @param booking The booking object to be persisted
     * @return The booking object that has been persisted
     * @throws ConstraintViolationException, ValidationException, Exception
     */
    public HotelBooking create(HotelBooking booking) throws Exception {
        log.info("HotelBookingRepository.create() - Creating booking, Dated: " + booking.getBookingDate() + " in hotel " + booking.getHotel().getHotel_name() + " and Customer " + booking.getCustomer().getFirstName());

        // Write the booking to the database.
        em.persist(booking);

        return booking;
    }
}
