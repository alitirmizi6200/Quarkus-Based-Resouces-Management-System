package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import com.example.resourceManagementSystem.customer.Customer;
import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@NamedQueries({
        @NamedQuery(
                name = HotelBooking.FIND_BY_HOTEL_AND_DATE,
                query = "SELECT b FROM HotelBooking b WHERE b.hotel = :hotel AND b.bookingDate = :bookingDate"
        ),
        @NamedQuery(
                name = HotelBooking.FIND_BY_ID,
                query = "SELECT b FROM HotelBooking b order by b.id ASC"
        )
})
@XmlRootElement
@Table(name = "HotelBooking")
public class HotelBooking implements Serializable  {
    private static final long serialVersionUID = 1L;

    public void setId(Long id) {
        this.id = id;
    }

    public static final String FIND_BY_ID = "HotelBooking.findById";
    public static final String FIND_BY_HOTEL_AND_DATE = "HotelBooking.findAllByHotelAndDate";

    @Id
    @Schema(hidden = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "hotel_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Hotel hotel;

    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "customer_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Customer customer;
    @NotNull
    @Temporal(TemporalType.DATE)
    @Future(message = "HotelBooking date must be in the future")
    @Column(nullable = false)
    private Date bookingDate;

    public Long getId() {
        return id;
    }


    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        if (this.hotel != null) {
            this.hotel.getBookings();
                    //.remove(this); // Remove this booking from the previous hotel
        }
        this.hotel = hotel;
        if (hotel != null) {
            hotel.getBookings();
//            .add(this); // Add this booking to the new hotel
        }
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        if (this.customer != null) {
            this.customer.getHotelBookings().remove(this); // Remove this booking from the previous hotel
        }
        this.customer = customer;
        if (customer != null) {
            customer.getHotelBookings().add(this); // Add this booking to the new hotel
        }
    }

    public void setHotelAndCustomer(Hotel hotel, Customer customer) {
        this.hotel = hotel;
        this.customer = customer;
        hotel.getBookings();
        //.add(this); // Maintain the bidirectional relationship
        customer.getHotelBookings().add(this); // Maintain the bidirectional relationship
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HotelBooking)) return false;
        HotelBooking booking = (HotelBooking) o;
        return Objects.equals(getId(), booking.getId()) && Objects.equals(getHotel(), booking.getHotel()) && Objects.equals(getCustomer(), booking.getCustomer()) && Objects.equals(getBookingDate(), booking.getBookingDate());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getHotel(), getCustomer(), getBookingDate());
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }
}
