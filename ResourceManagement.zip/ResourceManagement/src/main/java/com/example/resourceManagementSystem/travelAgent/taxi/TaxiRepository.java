package com.example.resourceManagementSystem.travelAgent.taxi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class TaxiRepository {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    EntityManager em;

    /**
     * Returns a List of all persisted {@link Taxi} objects, sorted by ID.
     *
     * @return List of Taxi objects
     */
    List<Taxi> findAll() {
        TypedQuery<Taxi> query = em.createNamedQuery(Taxi.FIND_ALL, Taxi.class);
        return query.getResultList();
    }

    /**
     * Returns a single Taxi object, specified by a Long id.
     *
     * @param id The id field of the Taxi to be returned
     * @return The Taxi with the specified id
     */
    Taxi findById(Long id) {
        return em.find(Taxi.class, id);
    }

    /**
     * Returns a single Taxi object, specified by a String taxi number.
     *
     * @param taxiNumber The taxi number field of the Taxi to be returned
     * @return The Taxi with the specified taxi number
     */
    Taxi findByTaxiNumber(String taxiNumber) {
        TypedQuery<Taxi> query = em.createNamedQuery(Taxi.FIND_BY_FLIGHT_NUMBER, Taxi.class)
                .setParameter("taxi_number", taxiNumber);
        return query.getSingleResult();
    }

    /**
     * Persists the provided Taxi object to the application database using the EntityManager.
     *
     * @param taxi The Taxi object to be persisted
     * @return The Taxi object that has been persisted
     * @throws ConstraintViolationException, ValidationException, Exception
     */
    Taxi create(Taxi taxi) throws Exception {
        log.info("TaxiRepository.create() - Creating Taxi with registration " + taxi.getRegistration());

        // Write the Taxi to the database.
        em.persist(taxi);

        return taxi;
    }

    /**
     * Deletes the provided Taxi object from the application database using the EntityManager.
     *
     * @param taxi The Taxi object to be deleted
     * @return The Taxi object that has been deleted
     * @throws Exception
     */
    public Taxi delete(Taxi taxi) throws Exception {
        log.info("TaxiRepository.delete() - Deleting Taxi with registration " + taxi.getRegistration());

        if (taxi.getId() != null) {
            /*
             * The Hibernate session (aka EntityManager's persistent context) is closed and invalidated after the commit(),
             * because it is bound to a transaction. The object goes into a detached status. If you open a new persistent
             * context, the object isn't known as in a persistent state in this new context, so you have to merge it.
             *
             * Merge sees that the object has a primary key (id), so it knows it is not new and must hit the database
             * to reattach it.
             *
             * Note, there is NO remove method which would just take a primary key (id) and a entity class as an argument.
             * You first need an object in a persistent state to be able to delete it.
             *
             * Therefore, we merge first and then we can remove it.
             */
            em.remove(em.merge(taxi));
        } else {
            log.info("TaxiRepository.delete() - No ID was found so can't Delete.");
        }

        return taxi;
    }
}
