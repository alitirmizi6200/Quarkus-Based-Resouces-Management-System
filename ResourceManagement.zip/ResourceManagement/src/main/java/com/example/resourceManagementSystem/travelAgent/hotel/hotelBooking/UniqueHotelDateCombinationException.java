package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

public class UniqueHotelDateCombinationException extends RuntimeException{

    public UniqueHotelDateCombinationException(String message) {
        super(message);
    }

    public UniqueHotelDateCombinationException(String message, Throwable cause) {
        super(message, cause);
    }

    public UniqueHotelDateCombinationException(Throwable cause) {
        super(cause);
    }
}
