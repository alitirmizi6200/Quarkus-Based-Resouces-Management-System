package com.example.resourceManagementSystem.travelAgent.flight;
//
//import javax.enterprise.context.ApplicationScoped;
//import javax.inject.Inject;
//import javax.validation.ConstraintViolation;
//import javax.validation.ConstraintViolationException;
//import javax.validation.Validator;
//import java.util.Date;
//import java.util.HashSet;
//import java.util.Objects;
//import java.util.Set;
//
//@ApplicationScoped
public class FlightBookingValidator {
//
//    @Inject
//    Validator validator;
//
//    @Inject
//    FlightBookingRepository bookingRepository;
//
//    /**
//     * Validates a FlightBooking entity.
//     *
//     * @param booking The FlightBooking entity to be validated
//     * @throws ConstraintViolationException If there are validation violations
//     */
//    public void validateFlight(FlightBooking booking) throws ConstraintViolationException {
//        // Create a bean validator and check for issues.
//        Set<ConstraintViolation<FlightBooking>> violations = validator.validate(booking);
//
//        if (!violations.isEmpty()) {
//            throw new ConstraintViolationException(new HashSet<>(violations));
//        }
//
//        // Check additional constraints
//        validateUniqueFlightAndDateCombination(booking);
//    }
//
//    /**
//     * Checks if a flight and date combination already exists.
//     *
//     * @param booking The FlightBooking entity to be validated
//     * @throws ConstraintViolationException If the flight and date combination is not unique
//     */
//    private void validateUniqueFlightAndDateCombination(FlightBooking booking) throws ConstraintViolationException {
//        // Check the uniqueness of the flight and date combination
//        if (isUniqueFlightAndDateCombination(booking.getFlight().getId(), booking.getBookingDate(), booking.getId())) {
//            throw new ConstraintViolationException("Booking for the specified flight and date already exists", new HashSet<>());
//        }
//    }
//
//    /**
//     * Checks if a flight and date combination already exists.
//     *
//     * @param flightId   The ID of the flight
//     * @param bookingDate The booking date
//     * @param bookingId   The ID of the current booking (null if it's a new booking being created)
//     * @return True if the flight and date combination already exists, false otherwise
//     */
//    private boolean isUniqueFlightAndDateCombination(Long flightId, Date bookingDate, Long bookingId) {
//        FlightBooking existingBooking = null;
//        FlightBooking bookingWithId = null;
//
//        try {
//            existingBooking = bookingRepository.findByFlightAndDate(flightId, bookingDate);
//        } catch (Exception e) {
//            // Ignore or log the exception
//        }
//
//        if (existingBooking != null && bookingId != null) {
//            try {
//                bookingWithId = bookingRepository.findById(bookingId);
//                if (bookingWithId != null && Objects.equals(bookingWithId.getBookingDate(), bookingDate)) {
//                    existingBooking = null;
//                }
//            } catch (Exception e) {
//                // Ignore or log the exception
//            }
//        }
//
//        return existingBooking != null;
//    }
}
