package com.example.resourceManagementSystem.travelAgent.flight;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/Flights")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class FlightRestService {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    FlightService flightService;

    @GET
    @Operation(summary = "Fetch Flight By number (For All flights response leave number field empty)", description = "Returns a JSON response of stored flight objects.")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Flight found"),
            @APIResponse(responseCode = "404", description = "Flight with number not found")
    })
    public Response retrieveAllFlights() {
        List<Flight> flights;
        flights = flightService.findAll();

        return Response.ok(flights).build();
    }

    @GET
    @Path("/{id:[0-9]+}")
    @Operation(
            summary = "Fetch a Flight by id",
            description = "Returns a JSON representation of the Flight object with the provided id."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Flight found"),
            @APIResponse(responseCode = "404", description = "Flight with id not found")
    })
    public Response retrieveFlightById(
            @Parameter(description = "Id of Flight to be fetched")
            @Schema(minimum = "0", required = true)
            @PathParam("id")
            long id) {
        Flight flight = flightService.findById(id);
        if (flight == null) {
            throw new RestServiceException("No Flight with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }
        log.info("findById " + id + ": found Flight = " + flight);
        return Response.ok(flight).build();
    }

    @POST
    @Operation(summary = "Add/Create Flight", description = "Add a new Flight to the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "201", description = "Flight created successfully."),
            @APIResponse(responseCode = "400", description = "Invalid Flight supplied in request body"),
            @APIResponse(responseCode = "409", description = "Flight supplied in request body conflicts with an existing Flight"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response createFlight(
            @Parameter(description = "JSON representation of Flight object to be added to the database", required = true)
            Flight flight) {
        if (flight == null) {
            throw new RestServiceException("Bad Request", Response.Status.BAD_REQUEST);
        }

        Response.ResponseBuilder builder;

        try {
            flightService.create(flight);
            builder = Response.status(Response.Status.CREATED).entity(flight);
        } catch (ConstraintViolationException ce) {
            Map<String, String> responseObj = new HashMap<>();
            for (ConstraintViolation<?> violation : ce.getConstraintViolations()) {
                responseObj.put(violation.getPropertyPath().toString(), violation.getMessage());
            }
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, ce);
        } catch (Exception e) {
            throw new RestServiceException(e);
        }

        log.info("createFlight completed. Flight = " + flight);
        return builder.build();
    }

    @DELETE
    @Path("/{id:[0-9]+}")
    @Operation(description = "Delete a Flight from the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "204", description = "The Flight has been successfully deleted"),
            @APIResponse(responseCode = "400", description = "Invalid Flight id supplied"),
            @APIResponse(responseCode = "404", description = "Flight with id not found"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response deleteFlight(
            @Parameter(description = "Id of Flight to be deleted", required = true)
            @Schema(minimum = "0")
            @PathParam("id")
            long id) {
        Response.ResponseBuilder builder;
        Flight flight = flightService.findById(id);
        if (flight == null) {
            throw new RestServiceException("No Flight with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }
        try {
            flightService.delete(flight);
            builder = Response.noContent();
        } catch (Exception e) {
            throw new RestServiceException(e);
        }
        log.info("deleteFlight completed. Flight = " + flight);
        return builder.build();
    }
}
