package com.example.resourceManagementSystem.travelAgent.taxi;

import com.example.resourceManagementSystem.travelAgent.travelAgentBooking.TravelAgentBooking;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import javax.persistence.*;
import javax.validation.constraints.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Objects;

@Entity
@NamedQueries({

        @NamedQuery(name = Taxi.FIND_ALL, query = "SELECT c FROM Taxi c order by c.id ASC"),
        @NamedQuery(name = Taxi.FIND_BY_FLIGHT_NUMBER, query = "SELECT c FROM Taxi c WHERE c.registration = :registration")
})
@XmlRootElement
@Table(name = "taxi", uniqueConstraints = @UniqueConstraint(columnNames = "registration"))

public class Taxi implements Serializable {
    /** Default value included to remove warning. Remove or modify at will. **/
    private static final long serialVersionUID = 1L;

    public static final String FIND_ALL = "Taxi.findAll";
    public static final String FIND_BY_FLIGHT_NUMBER = "Taxi.findByPhoneNumber";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
    private Long id;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{7}$", message = "Taxi number must be a non-empty alphanumeric string of 5 characters")
    @Column(name = "registration")
    private String registration;

    @NotNull
    @Pattern(regexp = "^(?!0$)[2-9]\\d?$|^1\\d?$|^20$", message = "Taxi number of seats should be a non-zero integer in the range of 2-20")
    @Column(name = "noOfSeats")
    private String noOfSeats;
    // Rest of the code...
    @Schema(hidden = true)
    @JsonIgnore
    @ManyToOne
    private TravelAgentBooking travelAgentbookings;

    public TravelAgentBooking getTravelAgentbookings() {
        return travelAgentbookings;
    }

    public void setTravelAgentbookings(TravelAgentBooking travelAgentbookings) {
        this.travelAgentbookings = travelAgentbookings;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public String getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(String noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Taxi)) return false;
        Taxi taxi = (Taxi) o;
        return Objects.equals(getId(), taxi.getId()) && Objects.equals(getRegistration(), taxi.getRegistration()) && Objects.equals(getNoOfSeats(), taxi.getNoOfSeats()) && Objects.equals(getTravelAgentbookings(), taxi.getTravelAgentbookings());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getRegistration(), getNoOfSeats(), getTravelAgentbookings());
    }
}

