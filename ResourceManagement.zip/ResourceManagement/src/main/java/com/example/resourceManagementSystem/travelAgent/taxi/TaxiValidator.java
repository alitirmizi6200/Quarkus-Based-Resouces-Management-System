package com.example.resourceManagementSystem.travelAgent.taxi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import javax.validation.Validator;
import java.util.HashSet;
import java.util.Set;

@ApplicationScoped
public class TaxiValidator {

    @Inject
    Validator validator;

    @Inject
    TaxiRepository taxiRepository;

    void validateTaxi(Taxi taxi) throws ConstraintViolationException, ValidationException {
        // Create a bean validator and check for issues.
        Set<ConstraintViolation<Taxi>> violations = validator.validate(taxi);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(new HashSet<>(violations));
        }

        // Check additional constraints for Taxi entity
        validateRegistration(taxi.getRegistration());
        validateNumberOfSeats(taxi.getNoOfSeats());
    }

    private void validateRegistration(String registration) throws ValidationException {
        if (registration == null || !registration.matches("^[a-zA-Z0-9]{7}$")) {
            throw new ValidationException("Taxi registration must be a non-empty alphanumeric string of 7 characters.");
        }
    }

    private void validateNumberOfSeats(String numberOfSeats) throws ValidationException {
        if (numberOfSeats == null || !numberOfSeats.matches("^(?!0$)[2-9]\\d?$|^1\\d?$|^20$")) {
            throw new ValidationException("Taxi number of seats should be a non-zero integer in the range of 2-20.");
        }
    }
}
