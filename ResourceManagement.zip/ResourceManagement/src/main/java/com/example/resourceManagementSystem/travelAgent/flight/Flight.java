package com.example.resourceManagementSystem.travelAgent.flight;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.example.resourceManagementSystem.travelAgent.travelAgentBooking.TravelAgentBooking;
//import uk.ac.newcastle.enterprisemiddleware.flightBooking.HotelBooking;

import javax.persistence.*;
import javax.validation.constraints.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Objects;

@Entity
@NamedQueries({
        @NamedQuery(name = Flight.FIND_ALL, query = "SELECT c FROM Flight c order by c.id ASC"),
        @NamedQuery(name = Flight.FIND_BY_FLIGHT_NUMBER, query = "SELECT c FROM Flight c WHERE c.flight_number = :flight_number")
})
@XmlRootElement
@Table(name = "flight", uniqueConstraints = @UniqueConstraint(columnNames = "flight_number"))

public class Flight implements Serializable {
    /** Default value included to remove warning. Remove or modify at will. **/
    private static final long serialVersionUID = 1L;

    public static final String FIND_ALL = "Flight.findAll";
    public static final String FIND_BY_FLIGHT_NUMBER = "Flight.findByPhoneNumber";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
    private Long id;

    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{5}$", message = "Flight number must be a non-empty alphanumeric string of 5 characters")
    @Column(name = "flight_number")
    private String flight_number;

    @NotNull
    @Pattern(regexp = "^[A-Z]{3}$", message = "Point of departure should be upper case 3 character length")
    @Column(name = "pointOfDeparture")
    private String pointOfDeparture;
    @NotNull
    @Pattern(regexp = "^[A-Z]{3}$", message = "destination should be upper case 3 character length and different from point of departure")
    @Column(name = "destination")
    private String destination;

    // Rest of the code...
    @Schema(hidden = true)
    @JsonIgnore
    @ManyToOne
    private TravelAgentBooking travelAgentbookings;

    public TravelAgentBooking getTravelAgentbookings() {
        return travelAgentbookings;
    }

    public void setTravelAgentbookings(TravelAgentBooking travelAgentbookings) {
        this.travelAgentbookings = travelAgentbookings;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFlight_number() {
        return flight_number;
    }

    public void setFlight_number(String flight_number) {
        this.flight_number = flight_number;
    }

    public String getPointOfDeparture() {
        return pointOfDeparture;
    }

    public void setPointOfDeparture(String pointOfDeparture) {
        this.pointOfDeparture = pointOfDeparture;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Flight)) return false;
        Flight flight = (Flight) o;
        return Objects.equals(id, flight.id) && Objects.equals(flight_number, flight.flight_number) && Objects.equals(pointOfDeparture, flight.pointOfDeparture) && Objects.equals(destination, flight.destination);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, flight_number, pointOfDeparture, destination);
    }
}

