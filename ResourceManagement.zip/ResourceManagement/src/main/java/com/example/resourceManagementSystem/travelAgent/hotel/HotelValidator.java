package com.example.resourceManagementSystem.travelAgent.hotel;

import com.example.resourceManagementSystem.customer.UniqueEmailException;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.NoResultException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import javax.validation.Validator;
import java.util.HashSet;
import java.util.Set;
@ApplicationScoped
public class HotelValidator {

    @Inject
    Validator validator;

    @Inject
    HotelRepository crud;


    void validateHotel(Hotel hotel) throws ConstraintViolationException, ValidationException {
        // Create a bean validator and check for issues.
        Set<ConstraintViolation<Hotel>> violations = validator.validate(hotel);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(new HashSet<ConstraintViolation<?>>(violations));
        }

        // Check the uniqueness of the email address
        if (PhoneNumberAlreadyExists(hotel.getPhone_number(), hotel.getId())) {
            throw new UniqueEmailException("Unique Email Violation");
        }
    }
    boolean PhoneNumberAlreadyExists(String PhoneNumber, Long id) {
        Hotel hotel = null;
        Hotel hotelWithID = null;
        try {
            hotel = crud.findByPhoneNumber(PhoneNumber);
        } catch (NoResultException e) {
            // ignore
        }

        if (hotel != null && id != null) {
            try {
                hotelWithID = crud.findById(id);
                if (hotelWithID != null && hotelWithID.getPhone_number().equals(PhoneNumber)) {
                    hotel = null;
                }
            } catch (NoResultException e) {
                // ignore
            }
        }
        return hotel != null;
    }

}