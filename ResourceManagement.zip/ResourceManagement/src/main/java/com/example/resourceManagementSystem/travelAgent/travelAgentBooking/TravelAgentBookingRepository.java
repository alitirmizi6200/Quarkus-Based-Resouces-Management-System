package com.example.resourceManagementSystem.travelAgent.travelAgentBooking;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class TravelAgentBookingRepository {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    EntityManager em;

    /**
     * Returns a List of all persisted {@link TravelAgentBooking} objects, sorted by id.
     *
     * @return List of TravelAgentBooking objects
     */
    List<TravelAgentBooking> findAll() {
        TypedQuery<TravelAgentBooking> query = em.createNamedQuery(TravelAgentBooking.FIND_ALL_BY_ID, TravelAgentBooking.class);
        return query.getResultList();
    }

    /**
     * Persists the provided TravelAgentBooking object to the application database using the EntityManager.
     *
     * @param travelAgentBooking The TravelAgentBooking object to be persisted
     * @return The TravelAgentBooking object that has been persisted
     * @throws Exception
     */
    @Transactional
    TravelAgentBooking create(TravelAgentBooking travelAgentBooking) throws Exception {
        log.info("TravelAgentBookingRepository.create() - Creating TravelAgentBooking with id " + travelAgentBooking.getId());

        // Write the TravelAgentBooking to the database.
        em.persist(travelAgentBooking);

        return travelAgentBooking;
    }
}
