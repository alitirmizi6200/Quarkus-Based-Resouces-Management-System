package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import com.example.resourceManagementSystem.customer.Customer;
import com.example.resourceManagementSystem.customer.CustomerService;
import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;
import com.example.resourceManagementSystem.travelAgent.hotel.HotelService;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.jboss.resteasy.reactive.Cache;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/Booking")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class HotelBookingRestService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    HotelBookingService bookingService;
    @Inject
    HotelService hotelService;
    @Inject
    CustomerService customerService;

    /**
     * Fetch all bookings ordered by booking date.
     *
     * @return Response containing a JSON array of bookings.
     */
    @GET
    @Cache
    @Operation(summary = "Fetch All HotelBooking", description = "Returns a JSON response of stored otes objects.")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="HotelBooking Response")
    })
    public Response retrieveAllHotels() {
        //Create an empty collection to contain the intersection of Bookings to be returned
        List<HotelBooking> bookings;
        bookings = bookingService.findAllBookings();
        return Response.ok(bookings).build();
    }
    /**
     * Fetch bookings in a hotel by ID.
     *
     * @param hotelId ID of the hotel to fetch bookings for.
     * @return Response containing a JSON array of bookings.
     */
    @GET
    @Path("/{hotelId:[0-9]+}/BookingsByotelID")
    @Operation(
            summary = "Fetch Bookings in a Hotel by id",
            description = "Returns a JSON array of all bookings in the specified hotel."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "bookings found"),
            @APIResponse(responseCode = "404", description = "bookings with hotel id not found")
    })
    public Response retrieveBookingsInHotel(
            @Parameter(description = "Id of Hotel to fetch booking for")
            @Schema(minimum = "1", required = true)
            @PathParam("hotelId")
            long hotelId) {

        Hotel hotel = hotelService.findById(hotelId);

        if (hotel == null) {
            throw new RestServiceException("No Hotel with the id " + hotelId + " was found!", Response.Status.NOT_FOUND);
        }

        List<HotelBooking> bookings = bookingService.findAllByHotelId(hotelId);
        return Response.ok(bookings).build();
    }
    /**
     * Fetch bookings for a customer by ID.
     *
     * @param customerID ID of the customer to fetch bookings for.
     * @return Response containing a JSON array of bookings.
     */
    @GET
    @Path("/{customerID:[0-9]+}/BookingsByCustomerID")
    @Operation(
            summary = "Fetch Bookings in a customer by id",
            description = "Returns a JSON array of all bookings in the specified customer."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "bookings found"),
            @APIResponse(responseCode = "404", description = "bookings with customer id not found")
    })
    public Response retrieveBookingsOfCustomer(
            @Parameter(description = "Id of customer to fetch booking for")
            @Schema(minimum = "1", required = true)
            @PathParam("customerID")
            long customerID) {

        Customer customer = customerService.findById(customerID);

        if (customer == null) {
            throw new RestServiceException("No customer with the id " + customerID + " was found!", Response.Status.NOT_FOUND);
        }

        List<HotelBooking> bookings = bookingService.findAllByCustomerId(customerID);
        return Response.ok(bookings).build();
    }
    /**
     * Fetch bookings by date and hotel ID.
     *
     * @param bookingDate Date of the booking.
     * @param hotelID     ID of the hotel.
     * @return Response containing a JSON array of bookings.
     */
    @GET
    @Path("/BookingsByDate")
    @Operation(
            summary = "Fetch Bookings by date and hotelID",
            description = "Returns a JSON array of all bookings for the specified date and hotelID."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "Bookings found"),
            @APIResponse(responseCode = "404", description = "No bookings found for the given criteria")
    })
    public Response retrieveBookingsByDateAndHotel(
            @Parameter(description = "Date of the booking")
            @QueryParam("bookingDate")
            @Schema(format = "date", example = "2023-11-14", required = true)
            Date bookingDate,
            @Parameter(description = "ID of the hotel")
            @QueryParam("hotelID")
            @Schema(minimum = "1", required = true)
            long hotelID
    ) {
        HotelBooking booking = bookingService.findByHotelAndDate(hotelID, bookingDate);

        if (booking == null) {
            throw new RestServiceException("No bookings found for the specified date and hotelID", Response.Status.NOT_FOUND);
        }

        return Response.ok(booking).build();
    }
    @POST
    @Path("/Bookings")
    @Consumes(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Create HotelBooking",
            description = "Create a new booking by providing hotelId, customerId, and booking date in JSON format."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "201", description = "HotelBooking created successfully."),
            @APIResponse(responseCode = "400", description = "Invalid data supplied in request body"),
            @APIResponse(responseCode = "404", description = "Hotel or Customer not found for the given IDs"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response createBooking(
            @Parameter(description = "HotelBooking details in JSON format", required = true)
            HotelBookingDTO BookingDTO
    ) {
        Response.ResponseBuilder builder;
        try {
            // Find the hotel by id
            Hotel hotel = hotelService.findById(BookingDTO.getHotelId());
            // Find the customer by id
            Customer customer = customerService.findById(BookingDTO.getCustomerId());

            if (hotel == null || customer == null) {
                throw new RestServiceException("Hotel or Customer not found for the given IDs", Response.Status.NOT_FOUND);
            }
            // Create a new HotelBooking instance
            HotelBooking booking = new HotelBooking();
            booking.setHotelAndCustomer(hotel, customer);
            // Set other booking properties as needed, including the booking date
            booking.setBookingDate(BookingDTO.getBookingDate());

            // Persist the new HotelBooking
            bookingService.create(booking);

            // Create a "Resource Created" 201 Response and pass the HotelBooking back in case it is needed.
            builder = Response.status(Response.Status.CREATED).entity(booking);

        } catch (ConstraintViolationException ce) {
            // Handle bean validation issues
            Map<String, String> responseObj = new HashMap<>();

            for (ConstraintViolation<?> violation : ce.getConstraintViolations()) {
                responseObj.put(violation.getPropertyPath().toString(), violation.getMessage());
            }
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, ce);

        } catch (UniqueHotelDateCombinationException e) {
            // Handle the unique constraint violation
            Map<String, String> responseObj = new HashMap<>();
            responseObj.put("Hotel And Date", "That Hotel is already booked for this date");
            throw new RestServiceException("Bad Request", responseObj, Response.Status.CONFLICT, e);
        } catch (Exception e) {
            throw new RestServiceException(e);
        }

        log.info("createBooking completed.");
        return builder.build();
    }
}
