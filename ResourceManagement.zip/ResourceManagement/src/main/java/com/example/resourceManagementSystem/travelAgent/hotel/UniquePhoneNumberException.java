package com.example.resourceManagementSystem.travelAgent.hotel;

import com.example.resourceManagementSystem.contact.Contact;

import javax.validation.ValidationException;
/**
 * <p>ValidationException caused if a Hotel's UniquePhoneNumberException conflicts with that of another Hotel.</p>
 *
 * <p>This violates the uniqueness constraint.</p>
 *
 * @author hugofirth
 * @see Contact
 */

public class UniquePhoneNumberException extends ValidationException{
    public UniquePhoneNumberException(String message) {
        super(message);
    }

    public UniquePhoneNumberException(String message, Throwable cause) {
        super(message, cause);
    }

    public UniquePhoneNumberException(Throwable cause) {
        super(cause);
    }
}

