package com.example.resourceManagementSystem.travelAgent.taxi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class TaxiService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    TaxiValidator validator;

    @Inject
    TaxiRepository taxiRepository;

    public List<Taxi> findAll() {
        return taxiRepository.findAll();
    }

    public Taxi findByTaxiNumber(String taxiNumber) {
        return taxiRepository.findByTaxiNumber(taxiNumber);
    }

    public Taxi findById(Long id) {
        return taxiRepository.findById(id);
    }

    public Taxi create(Taxi taxi) throws Exception {
        log.info("TaxiService.create() - Creating Taxi with registration " + taxi.getRegistration());

        // Check to make sure the data fits with the parameters in the Taxi model and passes validation.
        validator.validateTaxi(taxi);

        // Write the Taxi to the database.
        return taxiRepository.create(taxi);
    }

    public Taxi delete(Taxi taxi) throws Exception {
        log.info("TaxiService.delete() - Deleting Taxi with registration " + taxi.getRegistration());

        Taxi deletedTaxi = null;

        if (taxi.getId() != null) {
            deletedTaxi = taxiRepository.delete(taxi);
        } else {
            log.info("TaxiService.delete() - No ID was found so can't Delete.");
        }

        return deletedTaxi;
    }
}
