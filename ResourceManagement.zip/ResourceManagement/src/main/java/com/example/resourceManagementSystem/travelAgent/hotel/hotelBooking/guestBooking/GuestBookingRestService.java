package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.guestBooking;

import com.example.resourceManagementSystem.customer.Customer;
import com.example.resourceManagementSystem.customer.CustomerService;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.HotelBookingService;
import com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.HotelBooking;
import com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.UniqueHotelDateCombinationException;
import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;
import com.example.resourceManagementSystem.travelAgent.hotel.HotelService;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.*;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

@Path("/GuestBooking")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class GuestBookingRestService {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    HotelBookingService bookingService;

    @Inject
    HotelService hotelService;

    @Inject
    CustomerService customerService;

    @Inject
    UserTransaction userTransaction; // Inject the UserTransaction for manual transaction management

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Create Guest HotelBooking",
            description = "Create a new booking by providing hotelId, customerId, and booking date in JSON format."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "201", description = "HotelBooking created successfully."),
            @APIResponse(responseCode = "400", description = "Invalid data supplied in request body"),
            @APIResponse(responseCode = "404", description = "Hotel or Customer not found for the given IDs"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    public Response createBooking(
            @Parameter(description = "HotelBooking details in JSON format", required = true)
            GuestBooking guestBookingDTO
    ) {
        Response.ResponseBuilder builder;

        try {
            userTransaction.begin(); // Begin the manual transaction

            // Find the hotel by id
            Hotel hotel = hotelService.findById(guestBookingDTO.getHotelId());
            // Find the customer by id
            Customer customer = customerService.create(guestBookingDTO.getCustomer());

            if (hotel == null || customer == null) {
                throw new RestServiceException("Hotel or Customer not found for the given IDs", Response.Status.NOT_FOUND);
            }

            // Create a new HotelBooking instance
            HotelBooking booking = new HotelBooking();
            booking.setHotelAndCustomer(hotel, customer);
            // Set other booking properties as needed, including the booking date
            booking.setBookingDate(guestBookingDTO.getBookingDate());

            // Persist the new HotelBooking
            bookingService.create(booking);

            userTransaction.commit(); // Commit the transaction

            // Create a "Resource Created" 201 Response and pass the HotelBooking back in case it is needed.
            builder = Response.status(Response.Status.CREATED).entity(booking);

        } catch (ConstraintViolationException ce) {
            // Handle bean validation issues
            Map<String, String> responseObj = new HashMap<>();

            for (ConstraintViolation<?> violation : ce.getConstraintViolations()) {
                responseObj.put(violation.getPropertyPath().toString(), violation.getMessage());
            }
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, ce);

        } catch (UniqueHotelDateCombinationException e) {
            // Handle the unique constraint violation
            Map<String, String> responseObj = new HashMap<>();
            responseObj.put("Hotel And Date", "That Hotel is already booked for this date");
            throw new RestServiceException("Bad Request", responseObj, Response.Status.CONFLICT, e);
        } catch (Exception e) {
            try {
                userTransaction.rollback(); // Rollback the transaction in case of an exception
            } catch (SystemException se) {
                // Handle rollback exception
                log.warning("Transaction rollback failed: " + se.getMessage());
            }
            throw new RestServiceException(e);
        }

        log.info("createBooking completed.");
        return builder.build();
    }
}