package com.example.resourceManagementSystem.travelAgent.hotel;

import com.example.resourceManagementSystem.area.InvalidAreaCodeException;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.jboss.resteasy.reactive.Cache;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;


@Path("/Hotels")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class HotelRestService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    HotelService hotelService;
    /**
     * Fetch hotels by name or all hotels if name is not specified.
     *
     * @param hotel_name Name of the hotel (optional).
     * @return Response containing a JSON array of hotels.
     */
    @GET
    @Cache
    @Path("/hotel_name/{hotel_name}")
    @Operation(summary = "Fetch Hotel By name (For All hotels response leave Name field empty)", description = "Returns a JSON response of stored otes objects.")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Hotel found"),
            @APIResponse(responseCode = "404", description = "Hotel with address not found")
    })
    public Response retrieveAllHotels(@QueryParam("hotel_name") String hotel_name) {
        //Create an empty collection to contain the intersection of Hotels to be returned
        List<Hotel> Hotels;
            if(hotel_name == null) {
                Hotels = hotelService.findAllByName();
            } else {
                Hotels = hotelService.findByName(hotel_name);
            }
        return Response.ok(Hotels).build();
    }
    /**
     * Fetch a hotel by ID.
     *
     * @param id ID of the hotel to be fetched.
     * @return Response containing a JSON representation of the hotel.
     */
    @GET
    @Cache
    @Path("/{id:[0-9]+}")
    @Operation(
            summary = "Fetch a Hotel by id",
            description = "Returns a JSON representation of the Hotel object with the provided id."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Hotel found"),
            @APIResponse(responseCode = "404", description = "Hotel with id not found")
    })
    public Response retrieveHotelById(
            @Parameter(description = "Id of Hotel to be fetched")
            @Schema(minimum = "0", required = true)
            @PathParam("id")
            long id) {
        System.out.println(id);
        Hotel Hotel = hotelService.findById(id);
        if (Hotel == null) {
            // Verify that the Customer exists. Return 404, if not present.
            throw new RestServiceException("No Hotel with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }
        log.info("findById " + id + ": found Hotel = " + Hotel);

        return Response.ok(Hotel).build();
    }

    /**
     * Create a new hotel.
     *
     * @param Hotel JSON representation of the hotel to be added.
     * @return Response indicating the success or failure of the operation.
     */
    @SuppressWarnings("unused")
    @POST
    @Operation(summary = "Add/Create Hotel", description = "Add a new Hotel to the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "201", description = "Hotel created successfully."),
            @APIResponse(responseCode = "400", description = "Invalid Hotel supplied in request body"),
            @APIResponse(responseCode = "409", description = "Hotel supplied in request body conflicts with an existing Customer"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response createHotel(
            @Parameter(description = "JSON representation of Hotel object to be added to the database", required = true)
            Hotel Hotel) {

        if (Hotel == null) {
            throw new RestServiceException("Bad Request", Response.Status.BAD_REQUEST);
        }

        Response.ResponseBuilder builder;

        try {

            // Go add the new Customer.
            hotelService.create(Hotel);

            // Create a "Resource Created" 201 Response and pass the Customer back in case it is needed.
            builder = Response.status(Response.Status.CREATED).entity(Hotel);


        } catch (ConstraintViolationException ce) {
            //Handle bean validation issues
            Map<String, String> responseObj = new HashMap<>();

            for (ConstraintViolation<?> violation : ce.getConstraintViolations()) {
                responseObj.put(violation.getPropertyPath().toString(), violation.getMessage());
            }
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, ce);

        } catch (UniquePhoneNumberException e) {
            // Handle the unique constraint violation
            Map<String, String> responseObj = new HashMap<>();
            responseObj.put("Phone Number", "That Phone Number is already used, please use a unique Phone Number");
            throw new RestServiceException("Bad Request", responseObj, Response.Status.CONFLICT, e);
        } catch (InvalidAreaCodeException e) {
            Map<String, String> responseObj = new HashMap<>();
            responseObj.put("area_code", "The telephone area code provided is not recognised, please provide another");
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, e);
        } catch (Exception e) {
            // Handle generic exceptions
            throw new RestServiceException(e);
        }

        log.info("createCustomer completed. Hotel = " + Hotel);
        return builder.build();
    }


    /**
     * <p>Deletes a Hotel using the ID provided. If the ID is not present then nothing can be deleted.</p>
     *
     * <p>Will return a JAX-RS response with either 204 NO CONTENT or with a map of fields, and related errors.</p>
     *
     * @param id The Long parameter value provided as the id of the Hotel to be deleted
     * @return A Response indicating the outcome of the delete operation
     */
    @DELETE
    @Path("/{id:[0-9]+}")
    @Operation(description = "Delete a Hotel from the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "204", description = "The Hotel has been successfully deleted"),
            @APIResponse(responseCode = "400", description = "Invalid Hotel id supplied"),
            @APIResponse(responseCode = "404", description = "Hotel with id not found"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response deleteHotel(
            @Parameter(description = "Id of Hotel to be deleted", required = true)
            @Schema(minimum = "0")
            @PathParam("id")
            long id) {

        Response.ResponseBuilder builder;

        Hotel hotel = hotelService.findById(id);
        if (hotel == null) {
            // Verify that the Hotel exists. Return 404, if not present.
            throw new RestServiceException("No Hotel with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }

        try {
            hotelService.delete(hotel);

            builder = Response.noContent();

        } catch (Exception e) {
            // Handle generic exceptions
            throw new RestServiceException(e);
        }
        log.info("deleteHotel completed. Hotel = " + hotel);
        return builder.build();
    }
}
