package com.example.resourceManagementSystem.travelAgent.hotel;

import com.example.resourceManagementSystem.area.AreaService;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class HotelService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    HotelValidator validator;

    @Inject
    HotelRepository hotelCurd;

    //Removed temporarily due to non-existing AreaService
    @RestClient
    AreaService areaService;
    public List<Hotel> findByName(String name) {return hotelCurd.findAllByHotelName(name);}
    public List<Hotel> findAllByName() {return hotelCurd.findAllByName();}

    public Hotel findByPhoneNumber(String phone) {return hotelCurd.findByPhoneNumber(phone);
    }

    public Hotel findById(long id) {return hotelCurd.findById(id);}

    Hotel create(Hotel hotel) throws Exception {
        log.info("HotelService.create() - Creating " + hotel.getHotel_name());

        // Check to make sure the data fits with the parameters in the Customer model and passes validation.
        validator.validateHotel(hotel);

        // Write the Customer to the database.
        return hotelCurd.create(hotel);
    }

    public Hotel delete(Hotel hotel) throws Exception {
        log.info("delete() - Deleting " + hotel.toString());

        Hotel deletedHotel = null;

        if (hotel.getId() != null) {
            deletedHotel = hotelCurd.delete(hotel);
        } else {
            log.info("delete() - No ID was found so can't Delete.");
        }

        return deletedHotel;
    }
}
