package com.example.resourceManagementSystem.travelAgent.taxi;

import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Path("/Taxis")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TaxiRestService {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    TaxiService taxiService;

    @GET
    @Operation(summary = "Fetch Taxis By number (For All taxis response leave number field empty)", description = "Returns a JSON response of stored taxi objects.")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Taxi found"),
            @APIResponse(responseCode = "404", description = "Taxi with number not found")
    })
    public Response retrieveAllTaxis() {
        List<Taxi> taxis;
        taxis = taxiService.findAll();

        return Response.ok(taxis).build();
    }

    @GET
    @Path("/{id:[0-9]+}")
    @Operation(
            summary = "Fetch a Taxi by id",
            description = "Returns a JSON representation of the Taxi object with the provided id."
    )
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description ="Taxi found"),
            @APIResponse(responseCode = "404", description = "Taxi with id not found")
    })
    public Response retrieveTaxiById(
            @Parameter(description = "Id of Taxi to be fetched")
            @Schema(minimum = "0", required = true)
            @PathParam("id")
            long id) {
        Taxi taxi = taxiService.findById(id);
        if (taxi == null) {
            throw new RestServiceException("No Taxi with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }
        log.info("findById " + id + ": found Taxi = " + taxi);
        return Response.ok(taxi).build();
    }

    @POST
    @Operation(summary = "Add/Create Taxi", description = "Add a new Taxi to the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "201", description = "Taxi created successfully."),
            @APIResponse(responseCode = "400", description = "Invalid Taxi supplied in request body"),
            @APIResponse(responseCode = "409", description = "Taxi supplied in request body conflicts with an existing Taxi"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response createTaxi(
            @Parameter(description = "JSON representation of Taxi object to be added to the database", required = true)
            Taxi taxi) {
        if (taxi == null) {
            throw new RestServiceException("Bad Request", Response.Status.BAD_REQUEST);
        }

        Response.ResponseBuilder builder;

        try {
            taxiService.create(taxi);
            builder = Response.status(Response.Status.CREATED).entity(taxi);
        } catch (ConstraintViolationException ce) {
            Map<String, String> responseObj = new HashMap<>();
            for (ConstraintViolation<?> violation : ce.getConstraintViolations()) {
                responseObj.put(violation.getPropertyPath().toString(), violation.getMessage());
            }
            throw new RestServiceException("Bad Request", responseObj, Response.Status.BAD_REQUEST, ce);
        } catch (Exception e) {
            throw new RestServiceException(e);
        }

        log.info("createTaxi completed. Taxi = " + taxi);
        return builder.build();
    }

    @DELETE
    @Path("/{id:[0-9]+}")
    @Operation(description = "Delete a Taxi from the database")
    @APIResponses(value = {
            @APIResponse(responseCode = "204", description = "The Taxi has been successfully deleted"),
            @APIResponse(responseCode = "400", description = "Invalid Taxi id supplied"),
            @APIResponse(responseCode = "404", description = "Taxi with id not found"),
            @APIResponse(responseCode = "500", description = "An unexpected error occurred whilst processing the request")
    })
    @Transactional
    public Response deleteTaxi(
            @Parameter(description = "Id of Taxi to be deleted", required = true)
            @Schema(minimum = "0")
            @PathParam("id")
            long id) {
        Response.ResponseBuilder builder;
        Taxi taxi = taxiService.findById(id);
        if (taxi == null) {
            throw new RestServiceException("No Taxi with the id " + id + " was found!", Response.Status.NOT_FOUND);
        }
        try {
            taxiService.delete(taxi);
            builder = Response.noContent();
        } catch (Exception e) {
            throw new RestServiceException(e);
        }
        log.info("deleteTaxi completed. Taxi = " + taxi);
        return builder.build();
    }
}
