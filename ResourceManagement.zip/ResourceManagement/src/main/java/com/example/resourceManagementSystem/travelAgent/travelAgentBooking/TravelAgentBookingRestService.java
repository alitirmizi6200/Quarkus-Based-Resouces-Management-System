package com.example.resourceManagementSystem.travelAgent.travelAgentBooking;

import com.example.resourceManagementSystem.customer.Customer;
import com.example.resourceManagementSystem.customer.CustomerService;
import com.example.resourceManagementSystem.travelAgent.flight.Flight;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import com.example.resourceManagementSystem.travelAgent.flight.FlightService;
import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;
import com.example.resourceManagementSystem.travelAgent.hotel.HotelService;
import com.example.resourceManagementSystem.travelAgent.taxi.Taxi;
import com.example.resourceManagementSystem.travelAgent.taxi.TaxiService;
import com.example.resourceManagementSystem.util.RestServiceException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.logging.Logger;

@Path("/TravelAgentBookings")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TravelAgentBookingRestService {

    @Inject
    @Named("logger")
    Logger log;
    @Inject
    CustomerService customerService;
    @Inject
    HotelService hotelService;
    @Inject
    FlightService flightService;
    @Inject
    TaxiService taxiService;
    @Inject
    TravelAgentBookingRepository travelAgentBookingRepository;

    @GET
    @Operation(
            summary = "Fetch all TravelAgentBookings",
            description = "Returns a JSON response of stored TravelAgentBooking objects."
    )
    @APIResponse(responseCode = "200", description = "TravelAgentBookings found")
    public Response retrieveAllTravelAgentBookings() {
        List<TravelAgentBooking> travelAgentBookings = travelAgentBookingRepository.findAll();
        return Response.ok(travelAgentBookings).build();
    }

    @POST
    @Operation(
            summary = "Create TravelAgentBooking",
            description = "Add a new TravelAgentBooking to the database"
    )
    @APIResponse(responseCode = "201", description = "TravelAgentBooking created successfully.")
    @Transactional
    public Response createTravelAgentBooking(TravelAgentDTO travelAgentDTO) {
        if (travelAgentDTO == null) {
            throw new RestServiceException("Bad Request", Response.Status.BAD_REQUEST);
        }

        // Fetch related entities based on the provided IDs
        Customer customer = customerService.findById(travelAgentDTO.getCustomerId());
        Hotel hotel = hotelService.findById(travelAgentDTO.getHotelId());
        Flight flight = flightService.findById(travelAgentDTO.getFlightID());
        Taxi taxi = taxiService.findById(travelAgentDTO.getTaxiId());

        // Check if entities exist
        if (customer == null || hotel == null || flight == null || taxi == null) {
            throw new RestServiceException("One or more entities not found", Response.Status.BAD_REQUEST);
        }

        // Create TravelAgentBooking instance
        TravelAgentBooking travelAgentBooking = new TravelAgentBooking();
        travelAgentBooking.setCustomer(customer);
        travelAgentBooking.setHotel(hotel);
        travelAgentBooking.setFlight(flight);
        travelAgentBooking.setTaxi(taxi);

        // Set other properties as needed
        travelAgentBooking.setBookingDate(travelAgentDTO.getBookingDate());

        Response.ResponseBuilder builder;

        try {
            travelAgentBookingRepository.create(travelAgentBooking);
            builder = Response.status(Response.Status.CREATED).entity(travelAgentBooking);
        } catch (Exception e) {
            throw new RestServiceException(e);
        }

        log.info("createTravelAgentBooking completed. TravelAgentBooking = " + travelAgentBooking);
        return builder.build();
    }
}
