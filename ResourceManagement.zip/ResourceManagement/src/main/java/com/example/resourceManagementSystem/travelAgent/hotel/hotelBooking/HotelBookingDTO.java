package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import java.util.Date;

public class HotelBookingDTO {

    private Long hotelId;
    private Long customerId;
    private Date bookingDate;

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public HotelBookingDTO(Long hotelId, Long customerId, Date bookingDate) {
        this.hotelId = hotelId;
        this.customerId = customerId;
        this.bookingDate = bookingDate;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }
}
