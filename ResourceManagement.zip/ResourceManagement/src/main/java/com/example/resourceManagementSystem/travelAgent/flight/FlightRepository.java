package com.example.resourceManagementSystem.travelAgent.flight;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class FlightRepository {

    @Inject
    @Named("logger")
    Logger log;

    @Inject
    EntityManager em;

    List<Flight> findAll() {
        TypedQuery<Flight> query = em.createNamedQuery(Flight.FIND_ALL, Flight.class);
        return query.getResultList();
    }

    Flight findById(Long id) {
        return em.find(Flight.class, id);
    }

    Flight findByFlightNumber(String flightNumber) {
        TypedQuery<Flight> query = em.createNamedQuery(Flight.FIND_BY_FLIGHT_NUMBER, Flight.class)
                .setParameter("flight_number", flightNumber);
        return query.getSingleResult();
    }

    List<Flight> findAllByPointOfDeparture(String pointOfDeparture) {
        TypedQuery<Flight> query = em.createQuery("SELECT f FROM Flight f WHERE f.pointOfDeparture = :pointOfDeparture", Flight.class)
                .setParameter("pointOfDeparture", pointOfDeparture);
        return query.getResultList();
    }

    List<Flight> findAllByDestination(String destination) {
        TypedQuery<Flight> query = em.createQuery("SELECT f FROM Flight f WHERE f.destination = :destination", Flight.class)
                .setParameter("destination", destination);
        return query.getResultList();
    }

    Flight create(Flight flight) throws Exception {
        log.info("FlightRepository.create() - Creating " + flight.getFlight_number());

        em.persist(flight);

        return flight;
    }

    Flight delete(Flight flight) throws Exception {
        log.info("FlightRepository.delete() - Deleting " + flight.getFlight_number());

        if (flight.getId() != null) {
            em.remove(em.merge(flight));
        } else {
            log.info("FlightRepository.delete() - No ID was found so can't Delete.");
        }

        return flight;
    }
}