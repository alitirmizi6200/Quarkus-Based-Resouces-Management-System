package com.example.resourceManagementSystem.travelAgent.flight;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class FlightService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    FlightValidator validator;

    @Inject
    FlightRepository flightRepository;

    public List<Flight> findAll() {
        return flightRepository.findAll();
    }

    public Flight findByFlightNumber(String flightNumber) {
        return flightRepository.findByFlightNumber(flightNumber);
    }

    public List<Flight> findAllByPointOfDeparture(String pointOfDeparture) {
        return flightRepository.findAllByPointOfDeparture(pointOfDeparture);
    }

    public List<Flight> findAllByDestination(String destination) {
        return flightRepository.findAllByDestination(destination);
    }

    public Flight findById(Long id) {
        return flightRepository.findById(id);
    }

    public Flight create(Flight flight) throws Exception {
        log.info("FlightService.create() - Creating " + flight.getFlight_number());

        // Check to make sure the data fits with the parameters in the Flight model and passes validation.
        validator.validateFlight(flight);

        // Write the Flight to the database.
        return flightRepository.create(flight);
    }

    public Flight delete(Flight flight) throws Exception {
        log.info("FlightService.delete() - Deleting " + flight.getFlight_number());

        Flight deletedFlight = null;

        if (flight.getId() != null) {
            deletedFlight = flightRepository.delete(flight);
        } else {
            log.info("FlightService.delete() - No ID was found so can't Delete.");
        }

        return deletedFlight;
    }
}
