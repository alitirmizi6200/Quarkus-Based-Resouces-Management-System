package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class HotelBookingService {
    @Inject
    @Named("logger")
    Logger log;

    @Inject
    HotelBookingValidator validator;

    @Inject
    HotelBookingRepository Curd;

    @RestClient
    public List<HotelBooking> findAllBookings(){return Curd.findAllOrderedByID();}
    /**
     * Retrieves a list of bookings for a specific hotel ID.
     *
     * @param hotelId The ID of the hotel
     * @return List of bookings for the specified hotel
     */
    public List<HotelBooking> findAllByHotelId(Long hotelId) {return Curd.findAllByHotelId(hotelId);}
    /**
     * Retrieves a booking for a specific hotel and date.
     *
     * @param hotelID      The ID of the hotel
     * @param bookingDate  The date of the booking
     * @return HotelBooking for the specified hotel and date
     */
    public HotelBooking findByHotelAndDate(Long hotelID, Date bookingDate ) {return Curd.findByHotelAndDate(hotelID,bookingDate);}

    /**
     * Retrieves a list of bookings for a specific customer ID.
     *
     * @param customerID The ID of the customer
     * @return List of bookings for the specified customer
     */
    public List<HotelBooking> findAllByCustomerId(Long customerID) {return Curd.findAllByCustomerId(customerID);
    }
    /**
     * Retrieves a booking for a specific ID.
     *
     * @param id The ID of the booking
     * @return HotelBooking with the specified ID
     */
    public HotelBooking findById(long id) {return Curd.findById(id);}
    /**
     * Creates a new booking and persists it in the database.
     *
     * @param booking The booking to be created
     * @return The created booking
     * @throws Exception If an error occurs during the creation process
     */
    public HotelBooking create(HotelBooking booking) throws Exception {
        log.info("HotelBookingService.create() - Creating , Dated: " + booking.getBookingDate() + " in hotel " + booking.getHotel().getHotel_name() + " and Customer " + booking.getCustomer().getFirstName());


        // Check to make sure the data fits with the parameters in the Customer model and passes validation.
        validator.validateRoom(booking);

        // Write the Customer to the database.
        return Curd.create(booking);
    }

}
