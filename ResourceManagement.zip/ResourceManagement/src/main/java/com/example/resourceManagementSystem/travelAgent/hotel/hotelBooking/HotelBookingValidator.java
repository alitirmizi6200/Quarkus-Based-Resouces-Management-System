package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@ApplicationScoped
public class HotelBookingValidator {
    @Inject
    Validator validator;

    @Inject
    HotelBookingRepository bookingRepository;
    /**
     * Validates a HotelBooking entity.
     *
     * @param booking The Room entity to be validated
     * @throws ConstraintViolationException If there are validation violations
     */
    public void validateRoom(HotelBooking booking) throws ConstraintViolationException{
        // Create a bean validator and check for issues.
        Set<ConstraintViolation<HotelBooking>> violations = validator.validate(booking);

        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(new HashSet<>(violations));
        }

    }

    /**
     * Checks if a room number already exists within a hotel.
     *
     * @param bookingDate The booking date
     * @param hotelId    The ID of the hotel
     * @param bookingId     The ID of the current room (null if it's a new room being created)
     * @return True if the room number already exists within the hotel, false otherwise
     */
    private boolean isUniqueHotelAndDateCombination(Date bookingDate, Long hotelId, Long bookingId) {
        HotelBooking existingBooking = null;
        HotelBooking bookingWithId = null;

        try {
            existingBooking = bookingRepository.findByHotelAndDate(hotelId, bookingDate);
        } catch (Exception e) {
            // Ignore or log the exception
        }

        if (existingBooking != null && bookingId != null) {
            try {
                bookingWithId = bookingRepository.findById(bookingId);
                if (bookingWithId != null && Objects.equals(bookingWithId.getBookingDate(), bookingDate)) {
                    existingBooking = null;
                }
            } catch (Exception e) {
                // Ignore or log the exception
            }
        }

        return existingBooking != null;
    }

}
