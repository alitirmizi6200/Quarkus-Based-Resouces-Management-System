package com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.guestBooking;

import com.example.resourceManagementSystem.customer.Customer;

import java.util.Date;

public class GuestBooking {
    private Date bookingDate;
    private Long hotelId;
    private Customer customer;

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
