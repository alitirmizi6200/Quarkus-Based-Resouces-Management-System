package com.example.resourceManagementSystem.travelAgent.travelAgentBooking;

import com.example.resourceManagementSystem.customer.Customer;
import com.example.resourceManagementSystem.travelAgent.flight.Flight;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.example.resourceManagementSystem.travelAgent.hotel.Hotel;
import com.example.resourceManagementSystem.travelAgent.taxi.Taxi;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Entity
@NamedQueries({
        @NamedQuery(
                name = TravelAgentBooking.FIND_ALL_BY_ID,
                query = "SELECT b FROM TravelAgentBooking b order by b.id ASC"
        )
})
@XmlRootElement
@Table(name = "TravelAgentBooking")
public class TravelAgentBooking {
    private static final long serialVersionUID = 1L;
    public static final String FIND_ALL_BY_ID = "TravelAgentBooking.findAllById";

    @Id
    @Schema(hidden = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "customer_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Customer customer;
    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "hotel_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Hotel hotel;

    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "flight_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Flight flight;

    @Schema(hidden = true)
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "Taxi_id", nullable = false)
    @JsonManagedReference // Add this annotation to indicate the "parent" side of the relationship
    private Taxi taxi;

    @NotNull
    @Temporal(TemporalType.DATE)
    @Schema(hidden = true)
    @Future(message = "HotelBooking date must be in the future")
    @Column(nullable = false)
    private Date bookingDate;

    public Long getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Taxi getTaxi() {
        return taxi;
    }

    public void setTaxi(Taxi taxi) {
        this.taxi = taxi;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
