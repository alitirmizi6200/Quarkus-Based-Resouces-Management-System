package com.example.resourceManagementSystem.travelAgent.hotel;

import com.example.resourceManagementSystem.travelAgent.travelAgentBooking.TravelAgentBooking;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.example.resourceManagementSystem.travelAgent.hotel.hotelBooking.HotelBooking;

import javax.persistence.*;
import javax.validation.constraints.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Objects;

@Entity
@NamedQueries({
        @NamedQuery(name = Hotel.FIND_ALL, query = "SELECT c FROM Hotel c order by c.hotel_name ASC"),
        @NamedQuery(name = Hotel.FIND_BY_PHONENUMBER, query = "SELECT c FROM Hotel c WHERE c.phone_number = :phone_number")
})
@XmlRootElement
@Table(name = "hotel", uniqueConstraints = @UniqueConstraint(columnNames = "phone_Number"))

public class Hotel implements Serializable {
    /** Default value included to remove warning. Remove or modify at will. **/
    private static final long serialVersionUID = 1L;

    public static final String FIND_ALL = "Hotel.findAll";
    public static final String FIND_BY_PHONENUMBER = "Hotel.findByPhoneNumber";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
    private Long id;

    @NotNull
    @Size(min = 1, max = 25)
    @Pattern(regexp = "^[A-Za-z-' ]+$", message = "Please use a name without numbers or specials")
    @Column(name = "hotel_name")
    private String hotel_name;

    @NotNull
    @Pattern(regexp = "^0[0-9]{10}$", message = "Phone no. should start with 0 and be 11 characters in length")
    @Column(name = "phone_number")
    private String phone_number;
    @NotNull
    @Pattern(regexp = "^[a-zA-Z0-9]{6}$", message = "Hotel postcode must be a non-empty alphanumeric string of 6 characters")
    @Column(name = "postal_code")
    private String postal_code;

    @Schema(hidden = true)
    @JsonIgnore
    @ManyToOne
    private HotelBooking hotelbookings;
    @Schema(hidden = true)
    @JsonIgnore
    @ManyToOne
    private TravelAgentBooking travelAgentbookings;

    // Rest of the code...

    public HotelBooking getBookings() {
        return hotelbookings;
    }

    public void setBookings(HotelBooking bookings) {
        this.hotelbookings = bookings;
    }

    public TravelAgentBooking getTravelAgentbookings() {
        return travelAgentbookings;
    }

    public void setTravelAgentbookings(TravelAgentBooking travelAgentbookings) {
        this.travelAgentbookings = travelAgentbookings;
    }

    public Long getId() {
        return id;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String contactNumber) {
        this.phone_number = contactNumber;
    }

    public String getHotel_name() {
        return hotel_name;
    }

    public void setHotel_name(String hotel_name) {
        this.hotel_name = hotel_name;
    }

    public String getPostal_code() {return postal_code;}

    public void setPostal_code(String postal_code) {this.postal_code = postal_code;}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Hotel)) return false;
        Hotel hotel = (Hotel) o;
        return Objects.equals(getId(), hotel.getId()) && Objects.equals(getHotel_name(), hotel.getHotel_name()) && Objects.equals(getPostal_code(), hotel.getPostal_code());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getHotel_name(), getPostal_code());
    }


}

