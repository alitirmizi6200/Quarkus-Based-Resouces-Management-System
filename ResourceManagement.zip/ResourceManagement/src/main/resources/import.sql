-- Customer table
INSERT INTO Customer (first_name, last_name, email, phone_number)
VALUES
    ('Sam', 'Roberts', 'sam.roberts@example.com', '7775551234'),
    ('Emily', 'Davis', 'emily.davis@example.com', '4446667890'),
    ('Michael', 'Miller', 'michael.miller@example.com', '1239874560'),
    ('Olivia', 'Clark', 'olivia.clark@example.com', '9876543210'),
    ('Daniel', 'Brown', 'daniel.brown@example.com', '5551119999');

-- Hotel table
INSERT INTO hotel ( hotel_name, phone_number, postal_code)
VALUES
    ('Grand Hotel', '1234567890', '10001'),
    ('Luxury Inn', '9876543210', '90210'),
    ('Sunset Resort', '5551234567', '75001'),
    ('Beachfront Lodge', '1112223333', '33140'),
    ('Mountain Retreat', '9998887777', '60601');

-- HotelBooking table
INSERT INTO HotelBooking ( hotel_id, customer_id, bookingDate)
VALUES
    (1, 2, '2023-11-15'),
    (2, 3, '2023-11-16'),
    (3, 4, '2023-11-17'),
    (4, 5, '2023-11-18'),
    (5, 1, '2023-11-19');
-- Taxi table
INSERT INTO Taxi (registration, noOfSeats)
VALUES
    ('ABC123', '4'),
    ('XYZ789', '6'),
    ('123DEF', '8'),
    ('456GHI', '5'),
    ('789JKL', '7');

-- Flight table
INSERT INTO Flight (flight_number, pointOfDeparture, destination)
VALUES
    ('FL123', 'JFK', 'LHR'),
    ('FL456', 'LAX', 'CDG'),
    ('FL789', 'ORD', 'SIN'),
    ('FLABC', 'DFW', 'HKG'),
    ('FLXYZ', 'ATL', 'PEK');
-- TaxiBooking table