CREATE TABLE IF NOT EXISTS Contact (
       id INT PRIMARY KEY,
       firstName VARCHAR(25) NOT NULL,
       lastName VARCHAR(25) NOT NULL,
       email VARCHAR(255) NOT NULL,
       phoneNumber VARCHAR(255) NOT NULL,
       birthDate DATE NOT NULL,
       state VARCHAR(255)
);

-- Create Customer table
CREATE TABLE IF NOT EXISTS Customer (
        id INT PRIMARY KEY,
        firstName VARCHAR(25) NOT NULL,
        lastName VARCHAR(25) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phoneNumber VARCHAR(255) NOT NULL,
);

-- Hotel table
CREATE TABLE hotel (
       id INT PRIMARY KEY,
       hotel_name VARCHAR(25) NOT NULL,
       phone_number VARCHAR(25) NOT NULL,
       postal_code VARCHAR(255) NOT NULL,
       UNIQUE (phone_number)
);

CREATE TABLE IF NOT EXISTS HotelBooking (
       id INT PRIMARY KEY,
       hotel_id BIGINT NOT NULL,
       customer_id BIGINT NOT NULL,
       booking_date DATE NOT NULL,
       FOREIGN KEY (hotel_id) REFERENCES hotel(id) ON DELETE CASCADE,
       FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE
);